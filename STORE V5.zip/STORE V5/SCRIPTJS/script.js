// ARCHESZ STORE - FRONT-END DEMO ONLY (no real login / payment backend)

// Firebase Storage PLACEHOLDER (demo only - paste your own config to enable)
const firebaseConfig = { apiKey: "YOUR_API_KEY", authDomain: "YOUR_PROJECT.firebaseapp.com", storageBucket: "YOUR_PROJECT.appspot.com" };
async function uploadReceiptDemo(file) {
  // Real version: firebase.storage().ref('receipts/' + file.name).put(file)
  await new Promise((r) => setTimeout(r, 700));
  return 'demo://receipts/' + file.name;
}


// ===== Demo data store (localStorage, front-end only) =====
const DB = 'archesz_demo';
const loadDB = () => { try { return JSON.parse(localStorage.getItem(DB)) || { balance: 0, history: [] }; } catch { return { balance: 0, history: [] }; } };
const saveDB = (d) => { try { localStorage.setItem(DB, JSON.stringify(d)); } catch {} };
const fmtDate = (t) => new Date(t).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });

function toast(msg) {
  let t = document.querySelector('.toast');
  if (!t) { t = document.createElement('div'); t.className = 'toast'; document.body.appendChild(t); }
  t.textContent = msg; t.classList.add('show');
  clearTimeout(t._h); t._h = setTimeout(() => t.classList.remove('show'), 2600);
}
function go(url) { document.body.classList.add('leaving'); setTimeout(() => (location.href = url), 220); }
function countUp(el, to, ms = 900) {
  const t0 = performance.now();
  const step = (n) => { const k = Math.min((n - t0) / ms, 1), e = 1 - Math.pow(1 - k, 3); el.textContent = Math.round(to * e).toLocaleString(); if (k < 1) requestAnimationFrame(step); };
  requestAnimationFrame(step);
}
const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;

// Floating neon particles background
function initFX() {
  const au = document.createElement('div'); au.className = 'aurora'; au.innerHTML = '<i></i><i></i><i></i><i></i>'; document.body.prepend(au);
  if (matchMedia('(hover:hover)').matches && !reduced) {
    const cg = document.createElement('div'); cg.className = 'cursor-glow'; document.body.prepend(cg);
    addEventListener('pointermove', (e) => { cg.style.transform = `translate(${e.clientX}px,${e.clientY}px)`; });
  }
  if (reduced) return;
  const c = document.createElement('canvas'); c.id = 'fx'; document.body.prepend(c);
  const x = c.getContext('2d'); let w, h;
  const size = () => { w = c.width = innerWidth; h = c.height = innerHeight; }; size(); addEventListener('resize', size);
  const P = Array.from({ length: 46 }, (_, i) => ({ c: ['0,255,163','34,211,238','177,140,255','255,79,216'][i % 4], x: Math.random() * innerWidth, y: Math.random() * innerHeight, r: Math.random() * 1.8 + .4, v: Math.random() * .35 + .1, a: Math.random() * .5 + .15, d: Math.random() * 6 }));
  (function draw(t) {
    x.clearRect(0, 0, w, h);
    P.forEach((p) => {
      p.y -= p.v; p.x += Math.sin(t / 1800 + p.d) * .25; if (p.y < -5) { p.y = h + 5; p.x = Math.random() * w; }
      x.beginPath(); x.arc(p.x, p.y, p.r, 0, 6.283); x.fillStyle = `rgba(${p.c},${p.a})`; x.shadowColor = `rgb(${p.c})`; x.shadowBlur = 10; x.fill();
    });
    requestAnimationFrame(draw);
  })(0);
}

// Button ripple + page transitions + hero tilt
document.addEventListener('click', (e) => {
  const b = e.target.closest('.btn,.mini-btn,.filter-btn,.quick-btns button');
  if (b) {
    const r = b.getBoundingClientRect(), d = Math.max(r.width, r.height), s = document.createElement('span');
    s.className = 'ripple'; s.style.cssText = `width:${d}px;height:${d}px;left:${e.clientX - r.left - d / 2}px;top:${e.clientY - r.top - d / 2}px`;
    if (getComputedStyle(b).position === 'static') b.style.position = 'relative';
    b.style.overflow = 'hidden'; b.appendChild(s); setTimeout(() => s.remove(), 600);
  }
  const a = e.target.closest('a[href]');
  if (a && !a.target && !/^(#|http|mailto)/.test(a.getAttribute('href')) && !e.metaKey && !e.ctrlKey) { e.preventDefault(); go(a.href); }
});
addEventListener('pageshow', () => document.body.classList.remove('leaving'));

document.addEventListener('DOMContentLoaded', () => {
  initFX();
  const $ = (s) => document.querySelector(s);
  const $$ = (s) => document.querySelectorAll(s);

  // ---- AUTH ----
  $('#googleBtn')?.addEventListener('click', () => alert('Demo: Google sign-in is not connected.'));
  $('#loginForm')?.addEventListener('submit', (e) => { e.preventDefault(); go('verify.html'); });

  if ($('#timer')) {
    let t = 600;
    const tick = () => {
      const m = String(Math.floor(t / 60)).padStart(2, '0'), s = String(t % 60).padStart(2, '0');
      $('#timer').textContent = `Code expires in ${m}:${s}`;
      if (t > 0) t--;
    };
    tick(); setInterval(tick, 1000);
    const boxes = [...$$('.otp')];
    boxes.forEach((b, i) => {
      b.addEventListener('input', () => { b.value = b.value.replace(/\D/g, ''); if (b.value && boxes[i + 1]) boxes[i + 1].focus(); });
      b.addEventListener('keydown', (e) => { if (e.key === 'Backspace' && !b.value && boxes[i - 1]) boxes[i - 1].focus(); });
      b.addEventListener('paste', (e) => {
        const d = (e.clipboardData.getData('text') || '').replace(/\D/g, '').slice(0, 6);
        if (!d) return; e.preventDefault();
        [...d].forEach((c, k) => { if (boxes[k]) boxes[k].value = c; });
        boxes[Math.min(d.length, 5)].focus();
      });
    });
    $('#verifyForm').addEventListener('submit', (e) => { e.preventDefault(); go('setpass.html'); });
  }

  $('#passForm')?.addEventListener('submit', (e) => {
    e.preventDefault();
    const a = $('#np').value, b = $('#cp').value, err = $('#passErr');
    const msg = a.length < 8 ? 'Password must be at least 8 characters.' : a !== b ? 'Passwords do not match.' : '';
    err.hidden = !msg; err.textContent = msg;
    if (!msg) go('../HOMEPAGE/index.html');
  });

  // ---- SHOP: filter tabs ----
  const filterBtns = $$('.filter-btn');
  filterBtns.forEach((btn) => btn.addEventListener('click', () => {
    filterBtns.forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');
  }));

  // ---- BUY POINTS ----
  const pointInput = $('.input-points input');
  if (pointInput) {
    const num = () => parseInt(String(pointInput.value).replace(/,/g, '')) || 0;
    const update = () => {
      const v = num();
      $('#sumPts').textContent = v ? v.toLocaleString() + ' pts' : '—';
      $('#sumTotal').textContent = '₱' + v.toLocaleString();
    };
    pointInput.addEventListener('input', update);
    $$('.quick-btns button').forEach((btn) => btn.addEventListener('click', () => {
      pointInput.value = btn.textContent.replace(/,/g, '').trim();
      update();
    }));
    const balEl = $('.sum-row .purple-txt'); if (balEl) balEl.textContent = loadDB().balance.toLocaleString() + ' pts';
    update();

    // Screenshot upload (demo)
    let proof = null;
    const area = $('.upload-area');
    const picker = document.createElement('input');
    picker.type = 'file'; picker.accept = 'image/png,image/jpeg'; picker.hidden = true;
    document.body.appendChild(picker);
    area.addEventListener('click', () => picker.click());
    picker.addEventListener('change', async () => {
      const f = picker.files[0]; if (!f) return;
      if (f.size > 5 * 1024 * 1024) return alert('Max file size is 5MB.');
      area.innerHTML = `<i class="fas fa-spinner fa-spin upload-icon"></i><p>Uploading (demo)…</p>`;
      proof = await uploadReceiptDemo(f);
      area.innerHTML = `<i class="fas fa-circle-check upload-icon"></i><p>${f.name.replace(/</g, '&lt;')}</p><img src="${URL.createObjectURL(f)}" alt="Payment proof preview">`;
    });

    $('.full-btn').addEventListener('click', (e) => {
      e.preventDefault();
      if (num() < 50) return alert('Minimum purchase is 50 points.');
      if (!proof) return alert('Please upload your payment screenshot.');
      const d = loadDB();
      d.history.unshift({ id: 'ARC-' + Math.random().toString(36).slice(2, 8).toUpperCase(), pts: num(), status: 'pending', ts: Date.now(), proof });
      saveDB(d); toast('Request sent! Points will be credited after admin review.');
      setTimeout(() => go('../MYPOINTS/mypoints.html'), 1300);
    });
  }

  // ---- HOME: live balance + tilt ----
  const mpSub = $('.menu-card[href*="mypoints"] p');
  if (mpSub) mpSub.textContent = 'Balance: ' + loadDB().balance.toLocaleString() + ' pts';
  const hero = $('.hero-card:not(.bal-card)');
  if (hero && matchMedia('(hover:hover)').matches && !reduced) {
    hero.addEventListener('mousemove', (e) => { const r = hero.getBoundingClientRect(); const px = (e.clientX - r.left) / r.width - .5, py = (e.clientY - r.top) / r.height - .5; hero.style.transform = `perspective(900px) rotateY(${px * 5}deg) rotateX(${-py * 5}deg) translateY(-4px)`; });
    hero.addEventListener('mouseleave', () => (hero.style.transform = ''));
  }

  // ---- MY POINTS ----
  if ($('#histList')) {
    let f = 'all';
    const render = () => {
      const d = loadDB(), list = $('#histList');
      countUp($('#bal'), d.balance);
      const rows = d.history.filter((h) => f === 'all' || h.status === f);
      list.innerHTML = rows.length ? rows.map((h, i) => `
        <div class="hist-item" style="animation-delay:${i * 70}ms">
          <div class="menu-icon ${h.status === 'approved' ? 'green-icon' : 'gold-icon'}"><i class="fas ${h.status === 'approved' ? 'fa-circle-check' : 'fa-clock'}"></i></div>
          <div class="hist-info"><h3>Top-up via GCash</h3><p>${h.id} · ${fmtDate(h.ts)}</p></div>
          <div class="hist-right"><span class="hist-pts">+${h.pts.toLocaleString()}</span><span class="pill ${h.status}">${h.status}</span>
          ${h.status === 'pending' ? `<button class="mini-btn" data-id="${h.id}">Demo: approve</button>` : ''}</div>
        </div>`).join('') : `<div class="empty-state"><i class="fas fa-inbox"></i><p>No ${f === 'all' ? '' : f + ' '}history yet.<br>Buy points to get started.</p></div>`;
    };
    $$('#histTabs .filter-btn').forEach((b) => b.addEventListener('click', () => { f = b.dataset.f; render(); }));
    $('#histList').addEventListener('click', (e) => {
      const b = e.target.closest('.mini-btn'); if (!b) return;
      const d = loadDB(), h = d.history.find((x) => x.id === b.dataset.id);
      if (h && h.status === 'pending') { h.status = 'approved'; d.balance += h.pts; saveDB(d); toast(`+${h.pts} pts credited (demo admin approval)`); render(); }
    });
    $('#resetDemo').addEventListener('click', () => { saveDB({ balance: 0, history: [] }); toast('Demo data cleared'); render(); });
    render();
  }

  // ---- DONE BUY ----
  if ($('#doneList')) {
    const rows = loadDB().history.filter((h) => h.status === 'approved');
    $('#doneList').innerHTML = rows.length ? rows.map((h, i) => `
      <div class="hist-item" style="animation-delay:${i * 70}ms">
        <div class="menu-icon blue-icon"><i class="fas fa-check-circle"></i></div>
        <div class="hist-info"><h3>${h.pts.toLocaleString()} pts top-up</h3><p>Order ${h.id} · ${fmtDate(h.ts)}</p></div>
        <div class="hist-right"><span class="pill approved">completed</span><button class="mini-btn" data-demo>Receipt</button></div>
      </div>`).join('') : `<div class="empty-state"><i class="fas fa-box-open"></i><p>No completed orders yet.<br>Approved purchases show up here.</p></div>`;
    $('#doneList').addEventListener('click', (e) => { if (e.target.closest('[data-demo]')) toast('Demo only: no real files or downloads.'); });
  }
});
